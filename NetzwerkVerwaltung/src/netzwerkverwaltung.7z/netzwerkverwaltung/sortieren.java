/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package netzwerkverwaltung;

import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author manfred.fischer
 */
public class sortieren {
   private HashMap test = new HashMap();
   
   public sortieren(){
       test.put("a", 0);
       test.put("b", 1);
       test.put("c", 2);
       test.put("d", 3);
       test.put("e", 4);
       test.put("f", 5);
       test.put("g", 6);
       test.put("h", 7);
       test.put("i", 8);
       test.put("j", 9);
       test.put("k", 10);
       test.put("l", 11);
       test.put("m", 12);
       test.put("n", 13);
       test.put("o", 14);
       test.put("p", 15);
       test.put("q", 16);
       test.put("r", 17);
       test.put("s", 18);
       test.put("t", 19);
       test.put("u", 20);
       test.put("v", 21);
       test.put("w", 22);
       test.put("x", 23);
       test.put("y", 24);       
   }
   
   public ArrayList<ArrayList<String>> sortieren(ArrayList<ArrayList<String>> daten, int Spalte, int auswahl){
       
       
       return daten;
   }
   
   private ArrayList<ArrayList<String>> alp(ArrayList<ArrayList<String>> daten, int Spalte){
       
       
       
       return daten;
   }
}
